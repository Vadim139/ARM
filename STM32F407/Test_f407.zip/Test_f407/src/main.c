#include "stm32f4xx.h"
#include <stdio.h>
#include "stdlib.h"
#include "stdio.h"
#include "common.h"
#include "STM32F3_my.h"
#include "sbit.h"
#include "lcdlib.h"
#include "board.h"
#include "PCF8583.h"
#include "tm_stm32f4_i2c.h"
//#include "tm_stm32f4_usart.h"
#include "OV7670_I2C.h"

#define Led_Port GPIOB
#define Led1 GPIO_Pin_0
#define Led2 GPIO_Pin_1
#define Led3 GPIO_Pin_2

#define SW_Port GPIOE
#define SW1 GPIO_Pin_1
#define SW2 GPIO_Pin_2
#define SW3 GPIO_Pin_3
#define SW4 GPIO_Pin_5

#define VSYNC 	GPIO_Pin_1
#define OE 		GPIO_Pin_11
#define WRST 	GPIO_Pin_12
#define RRST 	GPIO_Pin_13
#define WE 		GPIO_Pin_14
#define RCLK 		GPIO_Pin_8


#define WRST_H()  GPIOB->BSRRL = WRST
#define WRST_L()  GPIOB->BSRRH  = WRST

#define RRST_H()  GPIOB->BSRRL = RRST
#define RRST_L()  GPIOB->BSRRH  = RRST

#define OE_H()    GPIOB->BSRRL = OE
#define OE_L()    GPIOB->BSRRH  = OE

#define WE_H()    GPIOB->BSRRL = WE
#define WE_L()    GPIOB->BSRRH  = WE

#define RCLK_H()    GPIOA->BSRRL = RCLK
#define RCLK_L()    GPIOA->BSRRH  = RCLK


extern volatile signed int contrast;
/* Adjust them for your own board. */

#if defined(BOARD_OLIMEX_STM32_E407)

/* STM32-E407 definitions (the GREEN LED) */

#define BLINK_PORT      GPIOC
#define BLINK_PIN       13
#define BLINK_RCC_BIT   RCC_AHB1Periph_GPIOC

#else

/* STM32F4DISCOVERY definitions (the GREEN LED) */

#define BLINK_PORT      GPIOD
#define BLINK_PIN       12
#define BLINK_RCC_BIT   RCC_AHB1Periph_GPIOD

#endif

#define BLINK_TICKS     SYSTICK_FREQUENCY_HZ/2

// ----------------------------------------------------------------------------
volatile uint32_t iii = 0;
int out = 0;
unsigned int  bn=3;

//void GPIO_Configuration(void)
//{
//	GPIO_InitTypeDef GPIO_InitStructure;
//
//	// LCD lines configuration
//  	RCC_AHB1PeriphClockCmd(RCC_AHBPeriph_ctrl, ENABLE);
//  	GPIO_InitStructure.GPIO_Pin = DATA | CLK | CS | RES ;
//  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
//  	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
//  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//  	GPIO_Init(PORT_ctrl, &GPIO_InitStructure);
//
////	// Joystick lines configuration
////	RCC_APB2PeriphClockCmd(RCC_APB2Periph_JOY, ENABLE);
////  	GPIO_InitStructure.GPIO_Pin = JOY_UP | JOY_DOWN;
////  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
////  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
////  	GPIO_Init(JOY_PORT, &GPIO_InitStructure);
//}
volatile u32 a = 0;
volatile u8 frame[25344];
volatile u8 c = 0;
volatile u8 p = 0;
int main(void)
 {
//iii = 4;
unsigned int k, l;
int ret = 0;
u8 data = 0;
	int ii;

//u8 frame[25344];
for(uint16_t o = 0;o<25344;o++)
{
	frame[o] = 10;
}

		/* Example use SysTick timer and read System core clock */
		SysTick_Config(168);  /* 1 us if clock frequency 168 MHz */

	//	SystemCoreClockUpdate();
		ii = SystemCoreClock;   /* This is a way to read the System core clock */

  LED_init();
  LEDs_on();

////	data = OV7670_read1(0x0A);
////	ret = OV7670_read(0x0A, &data);

		GPIO_PinInit(GPIOE, GPIO_Pin_0, GPIO_Mode_IN, GPIO_OType_PP, GPIO_PuPd_UP, GPIO_Speed_100MHz);// DATA 0-7
		GPIO_PinInit(GPIOE, GPIO_Pin_1, GPIO_Mode_IN, GPIO_OType_PP, GPIO_PuPd_UP, GPIO_Speed_100MHz);
		GPIO_PinInit(GPIOE, GPIO_Pin_2, GPIO_Mode_IN, GPIO_OType_PP, GPIO_PuPd_UP, GPIO_Speed_100MHz);
		GPIO_PinInit(GPIOE, GPIO_Pin_3, GPIO_Mode_IN, GPIO_OType_PP, GPIO_PuPd_UP, GPIO_Speed_100MHz);
		GPIO_PinInit(GPIOE, GPIO_Pin_4, GPIO_Mode_IN, GPIO_OType_PP, GPIO_PuPd_UP, GPIO_Speed_100MHz);
		GPIO_PinInit(GPIOE, GPIO_Pin_5, GPIO_Mode_IN, GPIO_OType_PP, GPIO_PuPd_UP, GPIO_Speed_100MHz);
		GPIO_PinInit(GPIOE, GPIO_Pin_6, GPIO_Mode_IN, GPIO_OType_PP, GPIO_PuPd_UP, GPIO_Speed_100MHz);
		GPIO_PinInit(GPIOE, GPIO_Pin_7, GPIO_Mode_IN, GPIO_OType_PP, GPIO_PuPd_UP, GPIO_Speed_100MHz);

		GPIO_PinInit(GPIOB, GPIO_Pin_1, GPIO_Mode_IN, GPIO_OType_PP, GPIO_PuPd_UP, GPIO_Speed_100MHz); //VSYNC
//
		GPIO_PinInit(GPIOB, GPIO_Pin_11, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_PuPd_UP, GPIO_Speed_100MHz); // OE
		GPIO_PinInit(GPIOB, GPIO_Pin_12, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_PuPd_UP, GPIO_Speed_100MHz); // WRST
		GPIO_PinInit(GPIOB, GPIO_Pin_13, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_PuPd_UP, GPIO_Speed_100MHz); // RRST
		GPIO_PinInit(GPIOB, GPIO_Pin_14, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_PuPd_UP, GPIO_Speed_100MHz); // WE
//
		GPIO_PinInit(GPIOA, GPIO_Pin_8, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_PuPd_UP, GPIO_Speed_100MHz); // RCLK

		STM_EVAL_PBInit(GPIO_Pin_0,1);

		I2C_Config(SCCB_Camera,I2C_Ack_Enable);

		USART_init();

			TIM1_PWM_Config(1, 1, 1680);
			TIM_SetCompare1(TIM1, 840);//(0us / 50us = 0.0)

			TIM_ITConfig(TIM1, TIM_IT_Update, ENABLE);

			NVIC_InitTypeDef nvicStructure;
			nvicStructure.NVIC_IRQChannel = TIM1_UP_TIM10_IRQn;
			nvicStructure.NVIC_IRQChannelPreemptionPriority = 0;
			nvicStructure.NVIC_IRQChannelSubPriority = 1;
			nvicStructure.NVIC_IRQChannelCmd = ENABLE;
			NVIC_Init(&nvicStructure);

//		  TIM_Config(TIM1,42000,2000);
		  TIM_Config(TIM2,42000,2000);
		  TIM_Config(TIM3,42000,1000);
		  TIM_Config(TIM8,42000,4000);
			///////////////////////////////////////////////////////////////////////////

		/* Configuration for QCIF format */

		// COM3 register: Enable format scaling
		ret = OV7670_read(0x0C, &data);
		data = data | 0b00001000;
		OV7670_write(0x0C, &data);

		// COM7 register: Select QCIF format
		ret = OV7670_read(0x0C, &data);
		data = (data & 0b11000111) | 0b00001000;
		OV7670_write(0x12, &data);
//		///////////////////////////////////////////////////////////////////////////

		OE_H();
		WE_H();
//		RCLK_H();

		WRST_H();
		RRST_H();

		WRST_L();
		RRST_L();
		_delay_ms(1);
		WRST_H();
		RRST_H();
		_delay_ms(1);
		EXTI_Config(GPIOB, VSYNC, EXTI_Trigger_Rising);
		TIM_ITConfig(TIM1, TIM_IT_Update, DISABLE);
		out = 1;
		_delay_ms(100);
		while(1)
		{
			while(bn == 0)
			{
				c=1;
				a = 0;
//		out = 1;

//		_delay_ms(100);

		OE_L();
		TIM_ITConfig(TIM1, TIM_IT_Update, ENABLE);
		_delay_ms(1500);
//		TIM_ITConfig(TIM1, TIM_IT_Update, DISABLE);
//		u8 p = 1;
//		u8 in = 0;
//		u32 g = 0;
//		for (uint32_t a = 0; a < 144; a++) {// * 176 * 2
//
//			RCLK_H();
//			_delay_us(1);
//			frame[a] = GPIOE->IDR & 0x00FF; //����λ
//			RCLK_L();
//
////			if(p % 2 == 0)
////			{
////				frame[g] = in;
////				g++;
////				p = 1;
////			}else
////				p++;
//
//			// LCD_WriteRAM(c_data);//дRGB���ݵ�TFT GRAM
////		               USART_SendData(USART2, frame[a]);
////		               _delay_us(40);
//
//		}

		u32 b = 0;
		for (int j = 0; j < 1; j++) {
			for (int i = 0; i < a; i++) {
				USART_SendData(USART2, frame[b]);
				b++;
				delay_qs(200);
			}
bn = 3;
		}
		}
 }
//		GPIO_PinSet(GPIOB,GPIO_Pin_11);
		///////////////////////////////////////////////////////////////////////////
//		  OE_L();
//		  WE_H();
////		  _delay_ms(1);
//		  bn = 3;
//		RRST_L();
//		RCLK_L();
//		RCLK_H();
//		RCLK_L();
//		RRST_H();
//		RCLK_H();
//		  for(uint32_t a=0;a<144*176;a++)
//		   {
//			  RCLK_L(); ;
//			  RCLK_H();
//			  RCLK_L();
//			  RCLK_H();
//		  }
////		  GPIO_PinSet(GPIOB,GPIO_Pin_11);
//	////////////////////////////////////////
//	while (1) {
//		if (bn == 2) {
//
//			RRST_L();
//			RCLK_L();
//			RCLK_H();
//			RCLK_L();
//			RRST_H();
//			RCLK_H();
//			u8 p = 1;
//			u8 in = 0;
//			u32 g = 0;
////			OE_H();
//			for (uint32_t a = 0; a < 144 * 176 * 2; a++) {
//
//				RCLK_L();
//				in = GPIOE->IDR & 0x00FF; //����λ
//				RCLK_H();
//
//				if(p % 2 == 0)
//				{
//					frame[g] = in;
//					g++;
//					p = 1;
//				}else
//					p++;
//
//				// LCD_WriteRAM(c_data);//дRGB���ݵ�TFT GRAM
////		               USART_SendData(USART2, frame[a]);
////		               _delay_us(40);
//
//			}
//			u32 b = 0;
//			for (int j = 0; j < 176; j++) {
//				for (int i = 0; i < 144; i++) {
//					USART_SendData(USART2, frame[b]);
//					b++;
//					delay_qs(50);
//				}
//
//			}
////		          	for (int j = 0; j < 176; j++)
////		          	{
////		          		for (int i = 0; i < 144; i++)
////		          		{
////		          			USART_SendData(USART2, data);
////		          			data++;
////		          			if (data > 15)
////		          				data = 0;
////		          			delay_qs(50);
////		          		}
////
////		          	}
//		           bn=3;
//		         }
//		       }
  //////////////////////////////////////////////////////////////////////////////////////////

//	GPIO_PinOut(Led_Port, Led1);
//	GPIO_PinOut(Led_Port, Led2);
//	GPIO_PinOut(Led_Port, Led3);
//	GPIO_PinOut(GPIOE, GPIO_Pin_All);

//	GPIO_PinIn(SW_Port, SW1);
//  GPIO_PinIn(SW_Port, SW2);
//	GPIO_PinIn(SW_Port, SW3);
//	GPIO_PinIn(SW_Port, SW4);
//	/* Set variables used */
//	    GPIO_InitTypeDef GPIO_InitStruct;
//	    EXTI_InitTypeDef EXTI_InitStruct;
//	    NVIC_InitTypeDef NVIC_InitStruct;
//
//	    /* Enable clock for GPIOD */
//	    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);
//	    /* Enable clock for SYSCFG */
//	    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
//
//	    /* Set pin as input */
//	    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
//	    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
//	    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_1;
//	    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
//	    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
//	    GPIO_Init(GPIOE, &GPIO_InitStruct);
//
//	    /* Tell system that you will use PD0 for EXTI_Line0 */
//	    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOE, EXTI_PinSource1);
//
//	    /* PD0 is connected to EXTI_Line0 */
//	    EXTI_InitStruct.EXTI_Line = EXTI_Line1;
//	    /* Enable interrupt */
//	    EXTI_InitStruct.EXTI_LineCmd = ENABLE;
//	    /* Interrupt mode */
//	    EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
//	    /* Triggers on rising and falling edge */
//	    EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Falling;
//	    /* Add to EXTI */
//	    EXTI_Init(&EXTI_InitStruct);
//
//	    /* Add IRQ vector to NVIC */
//	    /* PD0 is connected to EXTI_Line0, which has EXTI0_IRQn vector */
//	    NVIC_InitStruct.NVIC_IRQChannel = EXTI1_IRQn;
//	    /* Set priority */
//	    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0x00;
//	    /* Set sub priority */
//	    NVIC_InitStruct.NVIC_IRQChannelSubPriority = 0x00;
//	    /* Enable interrupt */
//	    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
//	    /* Add to NVIC */
//	    NVIC_Init(&NVIC_InitStruct);
//
//	    /* Enable clock for GPIOD */
//	    	    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);
//	    	    /* Enable clock for SYSCFG */
//	    	    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
//
//	    	    /* Set pin as input */
//	    	    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
//	    	    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
//	    	    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2;
//	    	    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
//	    	    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
//	    	    GPIO_Init(GPIOE, &GPIO_InitStruct);
//
//	    	    /* Tell system that you will use PD0 for EXTI_Line0 */
//	    	    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOE, EXTI_PinSource2);
//
//	    	    /* PD0 is connected to EXTI_Line0 */
//	    	    EXTI_InitStruct.EXTI_Line = EXTI_Line2;
//	    	    /* Enable interrupt */
//	    	    EXTI_InitStruct.EXTI_LineCmd = ENABLE;
//	    	    /* Interrupt mode */
//	    	    EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
//	    	    /* Triggers on rising and falling edge */
//	    	    EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Falling;
//	    	    /* Add to EXTI */
//	    	    EXTI_Init(&EXTI_InitStruct);
//
//	    	    /* Add IRQ vector to NVIC */
//	    	    /* PD0 is connected to EXTI_Line0, which has EXTI0_IRQn vector */
//	    	    NVIC_InitStruct.NVIC_IRQChannel = EXTI2_IRQn;
//	    	    /* Set priority */
//	    	    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0x00;
//	    	    /* Set sub priority */
//	    	    NVIC_InitStruct.NVIC_IRQChannelSubPriority = 0x00;
//	    	    /* Enable interrupt */
//	    	    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
//	    	    /* Add to NVIC */
//	    	    NVIC_Init(&NVIC_InitStruct);

//  	GPIO_PinIn(GPIOA, GPIO_Pin_0);
//  	GPIO_PinInit(GPIOA,GPIO_Pin_0,GPIO_Mode_IN,GPIO_OType_PP,GPIO_PuPd_NOPULL,GPIO_Speed_50MHz);
//  	EXTI_Config(GPIOA, GPIO_Pin_0,EXTI_Trigger_Rising);


//	EXTI_Config(SW_Port, SW1, EXTI_Trigger_Falling);
//	EXTI_Config(SW_Port, SW2, EXTI_Trigger_Falling);
//	EXTI_Config(SW_Port, SW3, EXTI_Trigger_Falling);
//	EXTI_Config(SW_Port, SW4, EXTI_Trigger_Falling);

//	Led_Port -> ODR ^= Led1;
//	Led_Port -> ODR ^= Led2;
//	Led_Port -> ODR ^= Led3;

//	TIM_Config(TIM3, 6000, 3000);
//	TIM_Config(TIM2, 6000, 6000);
//	TIM_Config(TIM7, 6000, 3000);
//	TIM1_PWM_Config(4, 71, 50);
//	TIM8_PWM_Config(4, 71, 50);
//	TIM4_PWM_Config(4, 83, 50);
//	TIM_SetCompare1(TIM4, 0);//(0us / 50us = 0.0)
//	TIM_SetCompare2(TIM4, 0);
//	TIM_SetCompare3(TIM4, 0);
//	TIM_SetCompare4(TIM4, 0);

//  TIM1_PWM_Config(4,16800,10000);

//  TIM_Config(TIM1,42000,2000);
//  TIM_Config(TIM2,42000,2000);
//  TIM_Config(TIM3,42000,1000);
//  TIM_Config(TIM8,42000,4000);

  int seconds = 0;

	// Initialize LCD
//    GPIO_Configuration();
//	InitLcdNokia();

//	MCO1_Init();
//	Hardware_InitI2C();
//	 ret = camera_read_reg(0x0A,&data);
	// PCF init


//	PCF8583_init();
//	LCDPutInt(reg,20,20,MEDIUM,WIB,WHITE,BLACK);

//	PCF8583_set_date(27,1,2015);
//	PCF8583_set_time(21,51,0,0);
	iii = 1;

//	lcd_set(PINK);

	// Set contrast
//	SetContrast(contrast);
//	_delay_ms(3000);
//	SetContrast(contrast);

	// *****************************************************************
	// Uncomment this code to find best contrast value. Contrast is
	// adjusted with joystick (up-down).
	// *****************************************************************

	// Draw three rectangles (red, green and blue)

//	for (k = 0; k < 44; k++)
//		for (l = 0; l < 132; l++)
//			LCDSetPixel(k, l, RED);
//	for (k = 44; k < 88; k++)
//		for (l = 0; l < 132; l++)
//			LCDSetPixel(k, l, GREEN);
//	for (k = 88; k < 132; k++)
//		for (l = 0; l < 132; l++)
//			LCDSetPixel(k, l, BLUE);

//	LCDPutInt(ret,20,20,MEDIUM,WIB,WHITE,BLACK);
//	LCDPutInt(data,40,20,MEDIUM,WIB,WHITE,BLACK);
//    puttime(20,20,3,MEDIUM,WIB,WHITE,BLACK);
//    putdate(40,20,3,MEDIUM,WIB,WHITE,BLACK);
//  TIM_TimeBaseInitTypeDef    TIM_InitStruct;
//
//  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
//
//  TIM_InitStruct.TIM_Prescaler = 42000 - 1;                // This will configure the clock to 2 kHz
//  TIM_InitStruct.TIM_CounterMode = TIM_CounterMode_Up;     // Count-up timer mode
//  TIM_InitStruct.TIM_Period = 2000 - 1;                    // 2 kHz down to 1 Hz = 1 second
//  TIM_InitStruct.TIM_ClockDivision = TIM_CKD_DIV1;        // Divide clock by 1
//  TIM_InitStruct.TIM_RepetitionCounter = 0;                // Set to 0, not used
//  TIM_TimeBaseInit(TIM2, &TIM_InitStruct);
//  /* TIM2 enable counter */
//  TIM_Cmd(TIM2, ENABLE);

  /* Infinite loop */
  while (1)
    {
//	  USART_SendData(USART2, 123);
//	  if(GPIO_GetState(GPIOA,GPIO_Pin_0))
//	  {
//		  USART_SendData(USART2, 159);
//	  }
//	  _delay_ms(2000);

//	  if (TIM_GetFlagStatus(TIM8, TIM_FLAG_Update) != RESET)
//	  {
//	  TIM_ClearFlag(TIM8, TIM_IT_Update);
//	  GPIO_ToggleBits(GPIOD, GPIO_Pin_12);
//	  }

      /* Assume the LED is active low */

      /* Turn on led by setting the pin low */
//      GPIO_ResetBits(BLINK_PORT, (1 << BLINK_PIN));

//      _delay_s(1);
//      Delay(BLINK_TICKS);

      /* Turn off led by setting the pin high */
//      GPIO_SetBits(BLINK_PORT, (1 << BLINK_PIN));
//
//      _delay_s(1);
//      Delay(BLINK_TICKS);

//      ++seconds;

    }
//EXTI4_IRQ
//  EXTI
}

//void TIM2_IRQHandler(void)
//{
////    if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
////    {
////    	LED4_T;
////    	iii++;
////    }
//    if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
//    {
//        TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
//        LED4_T;
//        iii++;
//    }
////	LED4_T;
//}

void USART2_IRQHandler(void) {
	uint16_t data = 0;
	data = USART_ReceiveData(USART2);
//	USART_SendData(USART2, data + 5);

//	for (int j = 0; j < 176; j++)
//	{
//		for (int i = 0; i < 144; i++)
//		{
//			USART_SendData(USART2, data);
//			data++;
//			if (data > 15)
//				data = 0;
//			delay_qs(50);
//		}
//
//	}
//	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, DISABLE);
//	OV7670_read(0x0A, &data);
//	USART_SendData(USART2, data);
//	USART_SendData(USART2, data);
	bn=0;
//	delay_ms(2000);
}

void TIM1_UP_TIM10_IRQHandler()
{
    if (TIM_GetITStatus(TIM1, TIM_IT_Update) != RESET)
    {
//		delay_qs(1);
//		frame[a] = GPIOE->IDR & 0x00FF;
//		USART_SendData(USART2, 20);
		if (c==1)
		{
			delay_qs(1);
//			delay(4);
//			frame[a] = GPIOE->IDR & 0x00FF;
			if(p % 2 == 0)
			{
				frame[a] = GPIOE->IDR & 0x00FF;
				a++;
				p = 1;
			}else
			{
//				GPIOE->IDR & 0x00FF;
				p++;
			}
		}
//			a++;
//		delay_qs(50);
		if(a == (144*176))
			TIM_ITConfig(TIM1, TIM_IT_Update, DISABLE);
//        if (iii)  frame[a]
//        {
////        	PCF8583_set_time(21,55,0,0);
////        puttime(20,20,3,MEDIUM,WIB,WHITE,BLACK);
////        putdate(40,20,3,MEDIUM,WIB,WHITE,BLACK);
//        }
        LED3_T;
        TIM_ClearITPendingBit(TIM1, TIM_IT_Update);
    }
}

void TIM2_IRQHandler()
{
    if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
    {
        TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
        LED4_T;
    }
}

void TIM8_UP_TIM13_IRQHandler()
{
    if (TIM_GetITStatus(TIM8, TIM_IT_Update) != RESET)
    {
        TIM_ClearITPendingBit(TIM8, TIM_IT_Update);
        LED5_T;    }

}

void TIM3_IRQHandler()
{
    if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
    {
        TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
        LED6_T;
    }
}


void EXTI0_IRQHandler(void)
{
		  USART_SendData(USART2, 147);
		  delay_ms(2000);
		  EXTI_ClearITPendingBit(EXTI_Line0);
}

void EXTI1_IRQHandler(void)
{
//    if(bn==0)
//    {
//     WRST_L();
//     WE_H();
//
//
//     bn=1;
//     WE_H();
//     WRST_H();
//    }
//    else if(bn==1)
//    {
//       WE_L();
//       bn=2;
//    }

if(out == 1)
{
	WE_H();
	out = 2;
}else if(out == 2)
{
//	WE_L();
}
//delay_ms(1000);
//	Led_Port -> ODR ^= Led1;
//	TIM_SetCompare1(TIM4, 0);//(0us / 50us = 0.0)
//	TIM_SetCompare2(TIM4, 0);
//	TIM_SetCompare3(TIM4, 0);
//	TIM_SetCompare4(TIM4, 0);
//	_delay_ms(500);
	EXTI_ClearITPendingBit(EXTI_Line1);

}

void EXTI2_IRQHandler(void)
{
	Led_Port -> ODR ^= Led2;
	TIM_SetCompare1(TIM4, 15);//(0us / 50us = 0.0)
	TIM_SetCompare2(TIM4, 15);
	TIM_SetCompare3(TIM4, 15);
	TIM_SetCompare4(TIM4, 15);
//	_delay_ms(500);
	EXTI_ClearITPendingBit(EXTI_Line2);

}

void EXTI3_IRQHandler(void)
{
	Led_Port -> ODR ^= Led3;
	TIM_SetCompare1(TIM4, 30);//(0us / 50us = 0.0)
	TIM_SetCompare2(TIM4, 30);
	TIM_SetCompare3(TIM4, 30);
	TIM_SetCompare4(TIM4, 30);
//	_delay_ms(500);
	EXTI_ClearITPendingBit(EXTI_Line3);

}

void EXTI9_5_IRQHandler(void)
{
	Led_Port -> ODR ^= Led1;
	Led_Port -> ODR ^= Led2;
	Led_Port -> ODR ^= Led3;
	TIM_SetCompare1(TIM4, 50);//(0us / 50us = 0.0)
	TIM_SetCompare2(TIM4, 50);
	TIM_SetCompare3(TIM4, 50);
	TIM_SetCompare4(TIM4, 50);
//	_delay_ms(500);
	EXTI_ClearITPendingBit(EXTI_Line5);

}
//void TIM8_CC_IRQHandler(void)
//{
//	if (TIM_GetFlagStatus(TIM8, TIM_FLAG_Update) != RESET)
//    {
//    	TIM_ClearFlag(TIM8, TIM_IT_Update);
//    	LED4_T;
//    	iii++;
//    }
//}
// ----------------------------------------------------------------------------

