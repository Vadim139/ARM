/**
 *
 */
/* Includes *******************************************************************/
#include "main.h"
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include "STM32F3_my.h"
#include "STM32F4_my.h"

Led led1(GPIOA, GPIO_PIN_1);

int main (void)
{
//	uint8_t tmp;
//	uint8_t tmpstr[6] = {0,};
//	int32_t ret = 0;
//	uint8_t memsize[2][8] = { {0,0,16,0,0,0,0,0},{2,2,2,2,2,2,2,2}};
  /* Initialization */

	RCC_HSEConfig(RCC_HSE_ON);
	while(!RCC_WaitForHSEStartUp())
	{
	}

//  Init_SysTick();
  SysTick_Config(180);

//  Led *leds[7];
  int k = 1;
//  leds[0] = new Led(GPIOA, GPIO_Pin_All);
//  leds[1] = new Led(GPIOB, GPIO_Pin_All);
//  leds[2] = new Led(GPIOC, GPIO_Pin_All);
//  leds[3] = new Led(GPIOD, GPIO_Pin_All);
//  leds[4] = new Led(GPIOE, GPIO_Pin_All);
//  leds[5] = new Led(GPIOF, GPIO_Pin_All);
//  leds[6] = new Led(GPIOG, GPIO_Pin_All);
//
//  leds[0]->Init();
//  leds[1]->Init();
//  leds[2]->Init();
//  leds[3]->Init();
//  leds[4]->Init();
//  leds[5]->Init();
//  leds[6]->Init();
//
//  leds[0]->Turn_on();
//  leds[1]->Turn_on();
//  leds[2]->Turn_on();
//  leds[3]->Turn_on();
//  leds[4]->Turn_on();
//  leds[5]->Turn_on();
//  leds[6]->Turn_on();


led1.Init();
led1.Turn_on();
TIM_Config((uint32_t)TIM1,18000,10000);
  while(1)
  {



  }

}
void TIM1_UP_TIM10_IRQHandler()
{
    if (TIM_GetITStatus(TIM1, TIM_IT_Update) != RESET)
    {

    	led1.Toggle();
        TIM_ClearITPendingBit(TIM1, TIM_IT_Update);
    }
}


#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  while (1)
  {}
}
#endif

/**
  * @}
  */

/**
  * @}
  */
