//
// Copyright (c) 2015 Liviu Ionescu.
// This file is part of the xPacks project (https://xpacks.github.io).
//

#ifndef STM32F4_CMSIS_DEVICE_H_
#define STM32F4_CMSIS_DEVICE_H_

#include "stm32f4xx.h"

#endif // STM32F4_CMSIS_DEVICE_H_
